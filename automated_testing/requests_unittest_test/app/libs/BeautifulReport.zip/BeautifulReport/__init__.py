"""
@Version: 1.0
@Project: BeautyReport
@Author: Raymond
@Data: 2017/11/16 下午6:01
@File: __init__.py
@License: MIT
"""

from .BeautifulReport import BeautifulReport


__all__ = ['BeautifulReport']
